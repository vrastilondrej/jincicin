<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/plugins/devtools/devtools.yaml',
    'modified' => 1553978299,
    'data' => [
        'enabled' => true
    ]
];
