<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/plugins/admin/languages/tlh.yaml',
    'modified' => 1553199618,
    'data' => [
        'PLUGIN_ADMIN' => [
            'LOGIN_BTN_FORGOT' => 'lIj',
            'BACK' => 'chap',
            'NORMAL' => 'motlh',
            'YES' => 'HIja\'',
            'NO' => 'Qo\'',
            'DISABLED' => 'Qotlh'
        ]
    ]
];
