<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/config/plugins/featherlight.yaml',
    'modified' => 1556466759,
    'data' => [
        'enabled' => true,
        'active' => true,
        'gallery' => true,
        'requirejs' => false,
        'openSpeed' => 250,
        'closeSpeed' => 250,
        'closeOnClick' => 'background',
        'closeOnEsc' => true,
        'root' => 'body',
        'initTemplate' => 'plugin://featherlight/js/featherlight.init.js'
    ]
];
