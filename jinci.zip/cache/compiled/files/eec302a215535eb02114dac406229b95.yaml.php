<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/plugins/flex-directory/languages.yaml',
    'modified' => 1558024333,
    'data' => [
        'en' => [
            'PLUGIN_FLEX_DIRECTORY' => [
                'TITLE' => 'FlexDirectory',
                'AFTER_SAVE' => 'After Save...',
                'CREATE_NEW' => 'Create New Item',
                'EDIT' => 'Edit Item',
                'LIST' => 'List Items'
            ]
        ]
    ]
];
