<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/config/scheduler.yaml',
    'modified' => 1558264247,
    'data' => [
        
    ]
];
