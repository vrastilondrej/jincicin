<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/themes/jinci-cin/blueprints/bylo.yaml',
    'modified' => 1555526259,
    'data' => [
        'extends@' => 'default',
        'form' => [
            'fields' => [
                'tabs' => [
                    'fields' => [
                        'program' => [
                            'type' => 'tab',
                            'title' => 'Program',
                            'style' => 'verical',
                            'fields' => [
                                'header.fieldset' => [
                                    'type' => 'fieldset',
                                    'title' => 'Nastavení stránky',
                                    'info' => '(Úvod, galerie...)',
                                    'icon' => 'cog',
                                    'collapsed' => true,
                                    'collapsible' => true,
                                    'fields' => [
                                        'header.text' => [
                                            'type' => 'editor',
                                            'label' => 'Ůvodní text'
                                        ],
                                        'header.image' => [
                                            'type' => 'file',
                                            'destination' => '@self',
                                            'label' => 'Logo pobočky',
                                            'style' => 'vertical',
                                            'accept' => [
                                                0 => 'image/*'
                                            ]
                                        ],
                                        'header.gallery' => [
                                            'type' => 'file',
                                            'label' => 'Galerie',
                                            'multiple' => true,
                                            'destination' => '@self',
                                            'style' => 'vertical',
                                            'accept' => [
                                                0 => 'image/*'
                                            ]
                                        ]
                                    ]
                                ],
                                'header.title' => [
                                    'type' => 'text',
                                    'label' => 'Název sekce',
                                    'classes' => 'large'
                                ],
                                'header.text' => [
                                    'type' => 'editor',
                                    'label' => 'Text'
                                ],
                                'header.gallery' => [
                                    'type' => 'file',
                                    'label' => 'Galerie',
                                    'multiple' => true,
                                    'destination' => '@self',
                                    'style' => 'vertical',
                                    'accept' => [
                                        0 => 'image/*'
                                    ]
                                ],
                                'header.days' => [
                                    'name' => 'Jednotlivé dny',
                                    'type' => 'list',
                                    'label' => 'Jednotlivé dny',
                                    'btnLabel' => 'Přidat den',
                                    'style' => 'vertical',
                                    'collapsed' => true,
                                    'fields' => [
                                        '.title' => [
                                            'type' => 'text',
                                            'label' => 'Název dne',
                                            'classes' => 'large'
                                        ],
                                        '.date' => [
                                            'type' => 'text',
                                            'label' => 'datum dne',
                                            'classes' => 'large'
                                        ],
                                        '.place' => [
                                            'type' => 'text',
                                            'label' => 'Místo, kde se program koná',
                                            'classes' => 'large'
                                        ],
                                        '.image' => [
                                            'type' => 'file',
                                            'label' => 'Galerie',
                                            'multiple' => true,
                                            'destination' => '@self',
                                            'style' => 'vertical',
                                            'accept' => [
                                                0 => 'image/*'
                                            ]
                                        ],
                                        '.items' => [
                                            'name' => 'Jednotlivé programy',
                                            'type' => 'list',
                                            'label' => 'Jednotlivé programy',
                                            'btnLabel' => 'Přidat program',
                                            'style' => 'vertical',
                                            'collapsed' => true,
                                            'fields' => [
                                                '.hour' => [
                                                    'type' => 'text',
                                                    'label' => 'Čas',
                                                    'classes' => 'large'
                                                ],
                                                '.name' => [
                                                    'type' => 'text',
                                                    'label' => 'Jméno programu'
                                                ]
                                            ]
                                        ]
                                    ]
                                ]
                            ]
                        ]
                    ]
                ]
            ]
        ]
    ]
];
