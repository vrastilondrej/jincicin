<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/config/security.yaml',
    'modified' => 1553978469,
    'data' => [
        'salt' => 'zLJFd7b4PBhCIW'
    ]
];
