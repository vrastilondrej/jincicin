<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/config/streams.yaml',
    'modified' => 1553978469,
    'data' => [
        
    ]
];
