<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'B:/Cloud/GDrive/_WebDesign/laragon/jinci/user/plugins/problems/problems.yaml',
    'modified' => 1553199618,
    'data' => [
        'enabled' => true,
        'built_in_css' => true
    ]
];
