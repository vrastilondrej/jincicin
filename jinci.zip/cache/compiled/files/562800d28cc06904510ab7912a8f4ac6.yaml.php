<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'themes://jinci-cin/jinci-cin.yaml',
    'modified' => 1553978442,
    'data' => [
        'enabled' => true,
        'dropdown' => [
            'enabled' => true
        ]
    ]
];
