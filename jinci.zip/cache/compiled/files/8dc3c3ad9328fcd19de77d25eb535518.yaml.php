<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'plugins://markdown-notices/markdown-notices.yaml',
    'modified' => 1553199618,
    'data' => [
        'enabled' => true,
        'built_in_css' => true,
        'level_classes' => [
            0 => 'yellow',
            1 => 'red',
            2 => 'blue',
            3 => 'green'
        ]
    ]
];
