<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* stezka-item.html.twig */
class __TwigTemplate_051a8438d457ee374d86052b29d3e2a4963b7a1389cd36f44fddb31904bd13fc extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("partials/base.html.twig", "stezka-item.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "   <div class=\"mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h3 class=\"text-center mb-8 cutive\">sídliště
            ";
        // line 7
        echo $this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "title", []);
        echo "
         </h3>

         <h1 class=\"text-center mb-8\">";
        // line 10
        echo $this->getAttribute(($context["page"] ?? null), "title", []);
        echo "</h1>
         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["header"] ?? null), "image", []));
        foreach ($context['_seq'] as $context["_key"] => $context["photo"]) {
            // line 14
            echo "                  <div class=\"px-16 sm:w-2/5 mx-auto mb-8\">
                     ";
            // line 15
            echo $this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "media", []), $this->getAttribute($context["photo"], "name", []), [], "array"), "html", [0 => $this->getAttribute(($context["item"] ?? null), "title", []), 1 => $this->getAttribute(($context["item"] ?? null), "title", []), 2 => "w-full"], "method");
            echo "
                  </div>

               ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['photo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 19
        echo "               ";
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->markdownFunction($this->getAttribute(($context["page"] ?? null), "content", []));
        echo "
            </div>
         </div>
         <div class=\"flex flex-wrap m-2 justify-center mb-8 md:mb-16\" id=\"swup4\">
            ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["header"] ?? null), "answers", []));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["answer"]) {
            // line 24
            echo "               <div class=\"w-full lg:w-1/3 flex answer answer-";
            echo $this->getAttribute($context["loop"], "index", []);
            echo " ";
            if ($this->getAttribute($context["answer"], "right", [])) {
                echo "right-answer";
            } else {
                echo "false-answer";
            }
            echo " cursor-pointer\">
                  <div class=\"m-4 p-4 lg:p-4 bg-primary border border-solid nice-border flex-1 flex items-end justify-center\" style=\"background-image:linear-gradient(rgba(14,40,77,0.2), rgba(14,40,77,0.4)),url('";
            // line 25
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["answer"], "image", []));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                echo "/";
                echo $this->getAttribute($context["image"], "path", []);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "'); background-size:cover;background-position: center center;\">
                     <div class=\"text-lg md:text-2xl text-secondary text-center p-4  mb-2 answer__text bg-primary\">";
            // line 26
            echo $this->getAttribute($context["answer"], "text", []);
            echo "<div class=\"click-answer text-base my-4\" style=\"display:none\">
                           ";
            // line 27
            if ($this->getAttribute($context["answer"], "right", [])) {
                echo ":-)";
            } else {
                echo ":-(
                           ";
            }
            // line 28
            echo "<br><br>";
            echo $this->getAttribute($context["answer"], "alerttext", []);
            echo "</div>
                     </div>

                  </div>
               </div>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['answer'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "         </div>
         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">
            <div data-budus=\"";
        // line 36
        echo $this->getAttribute(($context["header"] ?? null), "budu_s", []);
        echo "\" data-budutext=\"";
        echo $this->getAttribute(($context["header"] ?? null), "budu_text", []);
        echo "\" data-buduv=\"";
        echo $this->getAttribute(($context["header"] ?? null), "budu_v", []);
        echo "\" data-jsems=\"";
        echo $this->getAttribute(($context["header"] ?? null), "jsem_s", []);
        echo "\" data-jsemtext=\"";
        echo $this->getAttribute(($context["header"] ?? null), "jsem_text", []);
        echo "\" data-jsemv=\"";
        echo $this->getAttribute(($context["header"] ?? null), "jsem_v", []);
        echo "\" data-sirka=\"";
        echo ($this->getAttribute(($context["header"] ?? null), "map", []) - ($context["s"] ?? null));
        echo "\" data-vyska=\"";
        echo $this->getAttribute(($context["header"] ?? null), "map_v", []);
        echo "\" id=\"mapid\"></div>
         </div>
      </section>
      <div class=\"text-center p-8\">
         <a class=\"text-2xl text-white cutive\" href=\" ";
        // line 40
        echo $this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "url", []);
        echo " \">Zpět</a>
      </div>
   </div>
";
    }

    public function getTemplateName()
    {
        return "stezka-item.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 40,  160 => 36,  156 => 34,  135 => 28,  128 => 27,  124 => 26,  112 => 25,  101 => 24,  84 => 23,  76 => 19,  66 => 15,  63 => 14,  59 => 13,  53 => 10,  47 => 7,  42 => 4,  39 => 3,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/base.html.twig' %}

{% block content %}
   <div class=\"mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h3 class=\"text-center mb-8 cutive\">sídliště
            {{ page.parent.title }}
         </h3>

         <h1 class=\"text-center mb-8\">{{ page.title }}</h1>
         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               {% for photo in header.image %}
                  <div class=\"px-16 sm:w-2/5 mx-auto mb-8\">
                     {{ page.media[photo.name].html(item.title, item.title, 'w-full') }}
                  </div>

               {% endfor %}
               {{page.content|markdown}}
            </div>
         </div>
         <div class=\"flex flex-wrap m-2 justify-center mb-8 md:mb-16\" id=\"swup4\">
            {% for answer in header.answers %}
               <div class=\"w-full lg:w-1/3 flex answer answer-{{loop.index}} {% if answer.right %}right-answer{% else %}false-answer{% endif %} cursor-pointer\">
                  <div class=\"m-4 p-4 lg:p-4 bg-primary border border-solid nice-border flex-1 flex items-end justify-center\" style=\"background-image:linear-gradient(rgba(14,40,77,0.2), rgba(14,40,77,0.4)),url('{% for image in answer.image %}/{{ image.path}}{% endfor %}'); background-size:cover;background-position: center center;\">
                     <div class=\"text-lg md:text-2xl text-secondary text-center p-4  mb-2 answer__text bg-primary\">{{answer.text}}<div class=\"click-answer text-base my-4\" style=\"display:none\">
                           {% if answer.right %}:-){% else %}:-(
                           {% endif %}<br><br>{{answer.alerttext}}</div>
                     </div>

                  </div>
               </div>
            {% endfor %}
         </div>
         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">
            <div data-budus=\"{{header.budu_s}}\" data-budutext=\"{{header.budu_text}}\" data-buduv=\"{{header.budu_v}}\" data-jsems=\"{{header.jsem_s}}\" data-jsemtext=\"{{header.jsem_text}}\" data-jsemv=\"{{header.jsem_v}}\" data-sirka=\"{{header.map-s}}\" data-vyska=\"{{header.map_v}}\" id=\"mapid\"></div>
         </div>
      </section>
      <div class=\"text-center p-8\">
         <a class=\"text-2xl text-white cutive\" href=\" {{ page.parent.url }} \">Zpět</a>
      </div>
   </div>
{% endblock %}

{#
{% block bottomJS %}
   <script>
      swup.on('animationInDone', function () {
         {% for answer in header.answers %}
            \$(\".answer-{{loop.index}}\").on('click touch', function () {
               alert(\"{{answer.alerttext}}\");
            });{% endfor %}\$(\".answer\").on('click touch', function () {
            \$(this).addClass('answered');
         });
      });
   </script>
   <script>
      {% for answer in header.answers %}
         \$(\".answer-{{loop.index}}\").on('click touch', function () {
            alert(\"{{answer.alerttext}}\");
         });{% endfor %}\$(\".answer\").on('click touch', function () {
         \$(this).addClass('answered');
      });
   </script>
{% endblock %}
#}
", "stezka-item.html.twig", "B:\\Cloud\\GDrive\\_WebDesign\\laragon\\jinci\\user\\themes\\jinci-cin\\templates\\stezka-item.html.twig");
    }
}
