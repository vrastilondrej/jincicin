<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* bylo.html.twig */
class __TwigTemplate_435029901814a6110f6b28d0a06e61eea301e867d13f4684b3e202b766e63c95 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("partials/base.html.twig", "bylo.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "   <div class=\"mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h1 class=\"text-center mb-8 md:mb-16\">Bylo</h1>
         <div class=\"text-center mb-8 md:mb-16\" id=\"swup4\">
            <ul class=\"list-reset flex justify-center transition-fade\">
               ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "children", []));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 10
            echo "                  <li class=\"\">
                     <a data-swup-transition=\"full";
            // line 11
            echo $this->getAttribute($context["p"], "menu", []);
            echo "\" href=\"";
            echo $this->getAttribute($context["p"], "url", []);
            echo "\" class=\"";
            if ($this->getAttribute($context["p"], "active", [])) {
                echo " underline ";
            } else {
                echo "no-underline ";
            }
            echo " text-white transition hover:text-secondary p-4 text-lg md:text-3xl cutive\">";
            echo $this->getAttribute($context["p"], "menu", []);
            echo "</a>
                  </li>
               ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "            </ul>
         </div>

         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">

            ";
        // line 20
        echo "            ";
        // line 21
        echo "            ";
        // line 22
        echo "               <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\"> <p>
                  ";
        // line 23
        echo $this->getAttribute(($context["header"] ?? null), "text", []);
        echo "</p>
            </div>
         </div>
      </section>
   </div>
   <div class=\"flex flex-wrap m-2 justify-center\" id=\"swup4\">
      ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["page"] ?? null), "header", []), "days", []));
        foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
            // line 30
            echo "         <div class=\"w-full lg:w-1/2 flex\">
            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid nice-border flex-1\" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('";
            // line 31
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["day"], "image", []));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                echo "/";
                echo $this->getAttribute($context["image"], "path", []);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "'); background-size:cover;background-position: center center;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  \">
               <div class=\"text-lg md:text-2xl text-secondary\">";
            // line 33
            echo $this->getAttribute($context["day"], "title", []);
            echo "</div>
               <div class=\"text-2xl md:text-5xl mt-2 mb-4 md:mb-8\">";
            // line 34
            echo $this->getAttribute($context["day"], "place", []);
            echo "</div>

               ";
            // line 37
            echo "               ";
            // line 38
            echo "               ";
            // line 39
            echo "               ";
            // line 40
            echo "
                  ";
            // line 41
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["day"], "items", []));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 42
                echo "                     <div class=\"text-secondary list-reset2 mt-4\"> ";
                echo $this->getAttribute($context["item"], "hour", []);
                echo "
                     |
                     ";
                // line 44
                echo $this->getAttribute($context["item"], "name", []);
                echo "</div>
               ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 46
            echo "
            </div>
         </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['day'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "
      <div class=\"w-full lg:w-1/2 flex flex-wrap\">
         ";
        // line 52
        if ($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "children", []), "nextSibling", [0 => $this->getAttribute(($context["page"] ?? null), "path", [])], "method"), "path", [])) {
            // line 53
            echo "            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid  flex justify-center items-center flex-1 \" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["day"] ?? null), "image", []));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                echo "/";
                echo $this->getAttribute($context["image"], "path", []);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "'); background-size:cover;background-position: center center;\">
               <a class=\" ";
            // line 54
            if ($this->getAttribute(($context["p"] ?? null), "active", [])) {
                echo " text-secondary ";
            } else {
                echo " text-white ";
            }
            echo " no-underline transition hover:text-secondary p-4 text-3xl\" data-swup-transition=\" full";
            echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "children", []), "nextSibling", [0 => $this->getAttribute(($context["page"] ?? null), "path", [])], "method"), "slug", []);
            echo " \" href=\" ";
            echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "children", []), "nextSibling", [0 => $this->getAttribute(($context["page"] ?? null), "path", [])], "method"), "route", []);
            echo " \">
                  &lt;  Předchozí rok</a>
            </div>
         ";
        }
        // line 58
        echo "
         ";
        // line 59
        if ($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "children", []), "prevSibling", [0 => $this->getAttribute(($context["page"] ?? null), "path", [])], "method"), "path", [])) {
            // line 60
            echo "            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid  flex justify-center items-center flex-1 \" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["day"] ?? null), "image", []));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                echo "/";
                echo $this->getAttribute($context["image"], "path", []);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "'); background-size:cover;background-position: center center;\">
               <a class=\" ";
            // line 61
            if ($this->getAttribute(($context["p"] ?? null), "active", [])) {
                echo " text-secondary ";
            } else {
                echo " text-white ";
            }
            echo " no-underline transition hover:text-secondary p-4 text-3xl\" data-swup-transition=\" full";
            echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "children", []), "prevSibling", [0 => $this->getAttribute(($context["page"] ?? null), "path", [])], "method"), "slug", []);
            echo " \" href=\" ";
            echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "children", []), "prevSibling", [0 => $this->getAttribute(($context["page"] ?? null), "path", [])], "method"), "route", []);
            echo " \">
                  Následující rok &gt;
               </a>
            </div>
         ";
        }
        // line 66
        echo "
      </div>
   </div>
";
    }

    public function getTemplateName()
    {
        return "bylo.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  231 => 66,  215 => 61,  202 => 60,  200 => 59,  197 => 58,  182 => 54,  169 => 53,  167 => 52,  163 => 50,  154 => 46,  146 => 44,  140 => 42,  136 => 41,  133 => 40,  131 => 39,  129 => 38,  127 => 37,  122 => 34,  118 => 33,  105 => 31,  102 => 30,  98 => 29,  89 => 23,  86 => 22,  84 => 21,  82 => 20,  75 => 14,  56 => 11,  53 => 10,  49 => 9,  42 => 4,  39 => 3,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/base.html.twig' %}

{% block content %}
   <div class=\"mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h1 class=\"text-center mb-8 md:mb-16\">Bylo</h1>
         <div class=\"text-center mb-8 md:mb-16\" id=\"swup4\">
            <ul class=\"list-reset flex justify-center transition-fade\">
               {% for p in page.parent.children %}
                  <li class=\"\">
                     <a data-swup-transition=\"full{{p.menu}}\" href=\"{{ p.url }}\" class=\"{% if p.active %} underline {% else %}no-underline {% endif %} text-white transition hover:text-secondary p-4 text-lg md:text-3xl cutive\">{{ p.menu }}</a>
                  </li>
               {% endfor %}
            </ul>
         </div>

         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">

            {#   <div class=\"text-6xl mb-8 test text-center md:text-left\" id=\"swup3\">#}
            {#      <div>{{header.title}}</div>#}
            {#   </div>#}
               <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\"> <p>
                  {{header.text}}</p>
            </div>
         </div>
      </section>
   </div>
   <div class=\"flex flex-wrap m-2 justify-center\" id=\"swup4\">
      {% for day in page.header.days %}
         <div class=\"w-full lg:w-1/2 flex\">
            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid nice-border flex-1\" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('{% for image in day.image %}/{{ image.path}}{% endfor %}'); background-size:cover;background-position: center center;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  \">
               <div class=\"text-lg md:text-2xl text-secondary\">{{day.title}}</div>
               <div class=\"text-2xl md:text-5xl mt-2 mb-4 md:mb-8\">{{day.place}}</div>

               {#  {% for image in day.image %} #}
               {#  {{ dump(image) }} #}
               {#  {{ page.media[image.name] }} #}
               {# {% endfor %} #}

                  {% for item in day.items %}
                     <div class=\"text-secondary list-reset2 mt-4\"> {{item.hour}}
                     |
                     {{item.name}}</div>
               {% endfor %}

            </div>
         </div>
      {% endfor %}

      <div class=\"w-full lg:w-1/2 flex flex-wrap\">
         {% if page.parent.children.nextSibling(page.path).path %}
            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid  flex justify-center items-center flex-1 \" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('{% for image in day.image %}/{{ image.path}}{% endfor %}'); background-size:cover;background-position: center center;\">
               <a class=\" {% if p.active %} text-secondary {% else %} text-white {% endif %} no-underline transition hover:text-secondary p-4 text-3xl\" data-swup-transition=\" full{{ page.parent.children.nextSibling(page.path).slug }} \" href=\" {{ page.parent.children.nextSibling(page.path).route }} \">
                  &lt;  Předchozí rok</a>
            </div>
         {% endif %}

         {% if page.parent.children.prevSibling(page.path).path %}
            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid  flex justify-center items-center flex-1 \" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('{% for image in day.image %}/{{ image.path}}{% endfor %}'); background-size:cover;background-position: center center;\">
               <a class=\" {% if p.active %} text-secondary {% else %} text-white {% endif %} no-underline transition hover:text-secondary p-4 text-3xl\" data-swup-transition=\" full{{ page.parent.children.prevSibling(page.path).slug }} \" href=\" {{ page.parent.children.prevSibling(page.path).route }} \">
                  Následující rok &gt;
               </a>
            </div>
         {% endif %}

      </div>
   </div>
{% endblock %}
", "bylo.html.twig", "B:\\Cloud\\GDrive\\_WebDesign\\laragon\\jinci\\user\\themes\\jinci-cin\\templates\\bylo.html.twig");
    }
}
