<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* program.html.twig */
class __TwigTemplate_7cb3218645d12e76c151803b293fe38aa33182faba4756254fead5233ca2583c extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("partials/base.html.twig", "program.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "   <div class=\"container mx-auto transition-fade\">
      <section class=\"pt-8 md:pt-8 block program\">
         <h1 class=\"text-center mb-8 md:mb-32 text-5xl sm:text-6xl\">Program</h1>


         <div class=\"program__items md:w-4/5 mx-auto\">
            ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute(($context["page"] ?? null), "header", []), "section", []));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 11
            echo "               <h2 class=\"text-4xl sm:text-5xl mt-16 text-center md:text-left\">";
            echo $this->getAttribute($context["section"], "title", []);
            echo "</h2>


               ";
            // line 14
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["section"], "items", []));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 15
                echo "                  <div class=\"program__item py-4 flex flex-col items-center md:items-start md:flex-row flex-wrap border-secondary  py-4 my-8\">

                     <div class=\"md:w-1/3 md:pr-4 text-center md:text-left\">
                        <div class=\"program__time text-xl text-secondary\">";
                // line 18
                echo $this->getAttribute($context["item"], "hour", []);
                echo "</div>
                        <h3 class=\"program__title mt-2 font text-2xl md:text-xl\">
                           ";
                // line 20
                echo $this->getAttribute($context["item"], "title", []);
                echo "</h3>
                     </div>
                     <div class=\"md:w-1/2 program__text text-secondary\">
                        ";
                // line 23
                echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->markdownFunction($this->getAttribute($context["item"], "text", []));
                echo "
                     </div>
                     <div class=\"hidden md:block w-1/3 md:w-1/6 md:pr-4\">
                        ";
                // line 26
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["item"], "photo", []));
                foreach ($context['_seq'] as $context["_key"] => $context["photo"]) {
                    // line 27
                    echo "                           ";
                    echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "media", []), $this->getAttribute($context["photo"], "name", []), [], "array"), "cropResize", [0 => 400, 1 => 400], "method"), "html", [0 => $this->getAttribute($context["item"], "title", []), 1 => $this->getAttribute($context["item"], "title", []), 2 => "w-full"], "method");
                    echo "
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['photo'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 29
                echo "                     </div>
                  </div>
               </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 33
            echo "         ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "      </section>
   </div>
";
    }

    public function getTemplateName()
    {
        return "program.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 34,  109 => 33,  100 => 29,  91 => 27,  87 => 26,  81 => 23,  75 => 20,  70 => 18,  65 => 15,  61 => 14,  54 => 11,  50 => 10,  42 => 4,  39 => 3,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/base.html.twig' %}

{% block content %}
   <div class=\"container mx-auto transition-fade\">
      <section class=\"pt-8 md:pt-8 block program\">
         <h1 class=\"text-center mb-8 md:mb-32 text-5xl sm:text-6xl\">Program</h1>


         <div class=\"program__items md:w-4/5 mx-auto\">
            {% for section in page.header.section %}
               <h2 class=\"text-4xl sm:text-5xl mt-16 text-center md:text-left\">{{section.title}}</h2>


               {% for item in section.items %}
                  <div class=\"program__item py-4 flex flex-col items-center md:items-start md:flex-row flex-wrap border-secondary  py-4 my-8\">

                     <div class=\"md:w-1/3 md:pr-4 text-center md:text-left\">
                        <div class=\"program__time text-xl text-secondary\">{{ item.hour }}</div>
                        <h3 class=\"program__title mt-2 font text-2xl md:text-xl\">
                           {{ item.title }}</h3>
                     </div>
                     <div class=\"md:w-1/2 program__text text-secondary\">
                        {{item.text|markdown}}
                     </div>
                     <div class=\"hidden md:block w-1/3 md:w-1/6 md:pr-4\">
                        {% for photo in item.photo %}
                           {{ page.media[photo.name].cropResize(400, 400).html(item.title, item.title, 'w-full') }}
                        {% endfor %}
                     </div>
                  </div>
               </div>
            {% endfor %}
         {% endfor %}
      </section>
   </div>
{% endblock %}
", "program.html.twig", "B:\\Cloud\\GDrive\\_WebDesign\\laragon\\jinci\\user\\themes\\jinci-cin\\templates\\program.html.twig");
    }
}
