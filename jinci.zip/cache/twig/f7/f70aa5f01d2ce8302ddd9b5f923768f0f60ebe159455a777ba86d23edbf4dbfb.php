<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* stezka-menu.html.twig */
class __TwigTemplate_ce6d81b5f2dbabeecaf721a9b77ee882109fcf4dc1b7f041eea31ab88cdc4f44 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("partials/base.html.twig", "stezka-menu.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "   <div class=\"mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h1 class=\"text-center mb-8 md:mb-32\">";
        // line 6
        echo $this->getAttribute(($context["page"] ?? null), "title", []);
        echo "</h1>
         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               ";
        // line 9
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->markdownFunction($this->getAttribute(($context["header"] ?? null), "text", []));
        echo "
            </div>
         </div>
      </section>
   </div>
   <div class=\"flex flex-wrap m-2 justify-center\" id=\"swup4\">
      ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["page"] ?? null), "children", []));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 16
            echo "         <a href=\"";
            echo $this->getAttribute($context["p"], "url", []);
            echo "\" class=\"w-full lg:w-1/2 flex  no-underline\">
            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid nice-border flex-1\" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('";
            // line 17
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["day"] ?? null), "image", []));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                echo "/";
                echo $this->getAttribute($context["image"], "path", []);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "'); background-size:cover;background-position: center center;\">
               <div class=\"text-lg md:text-2xl text-secondary\">";
            // line 18
            echo $this->getAttribute($context["p"], "title", []);
            echo "</div>
               ";
            // line 19
            echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->dump($this->env, $context, ($context["image"] ?? null));
            echo "
               ";
            // line 20
            echo $this->getAttribute($this->getAttribute(($context["page"] ?? null), "media", []), $this->getAttribute(($context["image"] ?? null), "name", []), [], "array");
            echo "
            </div>
         </a>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "   </div>
";
    }

    public function getTemplateName()
    {
        return "stezka-menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  100 => 24,  90 => 20,  86 => 19,  82 => 18,  70 => 17,  65 => 16,  61 => 15,  52 => 9,  46 => 6,  42 => 4,  39 => 3,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/base.html.twig' %}

{% block content %}
   <div class=\"mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h1 class=\"text-center mb-8 md:mb-32\">{{page.title}}</h1>
         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               {{header.text|markdown}}
            </div>
         </div>
      </section>
   </div>
   <div class=\"flex flex-wrap m-2 justify-center\" id=\"swup4\">
      {% for p in page.children %}
         <a href=\"{{ p.url }}\" class=\"w-full lg:w-1/2 flex  no-underline\">
            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid nice-border flex-1\" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('{% for image in day.image %}/{{ image.path}}{% endfor %}'); background-size:cover;background-position: center center;\">
               <div class=\"text-lg md:text-2xl text-secondary\">{{p.title}}</div>
               {{ dump(image) }}
               {{ page.media[image.name] }}
            </div>
         </a>
      {% endfor %}
   </div>
{% endblock %}
", "stezka-menu.html.twig", "B:\\Cloud\\GDrive\\_WebDesign\\laragon\\jinci\\user\\themes\\jinci-cin\\templates\\stezka-menu.html.twig");
    }
}
