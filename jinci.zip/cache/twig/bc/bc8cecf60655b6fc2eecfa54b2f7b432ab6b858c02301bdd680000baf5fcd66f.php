<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* stezka-list.html.twig */
class __TwigTemplate_74225a395c20834ea1008c069284bcb7bd9f3c1b881aa6da907d35346304aa14 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("partials/base.html.twig", "stezka-list.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "   <div class=\"mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h2 class=\"text-center text-2xl cutive\">sídliště</h2>

         <h1 class=\"text-center mb-8 md:mb-16\">";
        // line 8
        echo $this->getAttribute(($context["page"] ?? null), "title", []);
        echo "</h1>
         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               ";
        // line 11
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->markdownFunction($this->getAttribute(($context["header"] ?? null), "text", []));
        echo "
            </div>
         </div>
      </section>
   </div>
   <div class=\"flex flex-wrap m-2 justify-center mb-8 md:mb-16\" id=\"swup4\">
      ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["page"] ?? null), "children", []));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 18
            echo "         <a href=\"";
            echo $this->getAttribute($context["p"], "url", []);
            echo "\" class=\"w-full lg:w-1/2 flex  no-underline\">
            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid nice-border flex-1\" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('";
            // line 19
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["day"] ?? null), "image", []));
            foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
                echo "/";
                echo $this->getAttribute($context["image"], "path", []);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            echo "'); background-size:cover;background-position: center center;\">
               <div class=\"text-lg md:text-2xl text-secondary flex justify-between items-center\">";
            // line 20
            echo $this->getAttribute($context["p"], "title", []);
            echo "
                  ";
            // line 21
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($context["p"], "header", []), "image", []));
            foreach ($context['_seq'] as $context["_key"] => $context["photo"]) {
                // line 22
                echo "                     ";
                echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->dump($this->env, $context, $context["p"]);
                echo "

                     ";
                // line 24
                echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->dump($this->env, $context, $this->getAttribute($context["p"], "url", []));
                echo "
                     <div class=\"w-1/5\" style=\"width: 50px\">
                        ";
                // line 26
                echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "find", [0 => $this->getAttribute($context["p"], "url", [])], "method"), "media", []), $this->getAttribute($context["photo"], "name", []), [], "array"), "html", [0 => $this->getAttribute(($context["item"] ?? null), "title", []), 1 => $this->getAttribute(($context["item"] ?? null), "title", []), 2 => "w-full"], "method");
                echo "
                     </div>

                  ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['photo'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 30
            echo "               </div>
            </div>
         </a>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "   </div>
   <div class=\"text-center\">
      <a class=\"text-2xl text-white cutive\" href=\" ";
        // line 36
        echo $this->getAttribute($this->getAttribute(($context["page"] ?? null), "parent", []), "url", []);
        echo " \">Zpět</a>
   </div>
";
    }

    public function getTemplateName()
    {
        return "stezka-list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  126 => 36,  122 => 34,  113 => 30,  103 => 26,  98 => 24,  92 => 22,  88 => 21,  84 => 20,  72 => 19,  67 => 18,  63 => 17,  54 => 11,  48 => 8,  42 => 4,  39 => 3,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/base.html.twig' %}

{% block content %}
   <div class=\"mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h2 class=\"text-center text-2xl cutive\">sídliště</h2>

         <h1 class=\"text-center mb-8 md:mb-16\">{{ page.title }}</h1>
         <div class=\"bylo__items lg:w-4/5 mx-auto   transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               {{header.text|markdown}}
            </div>
         </div>
      </section>
   </div>
   <div class=\"flex flex-wrap m-2 justify-center mb-8 md:mb-16\" id=\"swup4\">
      {% for p in page.children %}
         <a href=\"{{ p.url }}\" class=\"w-full lg:w-1/2 flex  no-underline\">
            <div class=\"m-4 p-4 lg:p-8 bg-primary border border-solid nice-border flex-1\" style=\"background-image:linear-gradient(rgba(14,40,77,0.7), rgba(14,40,77,0.9)),url('{% for image in day.image %}/{{ image.path}}{% endfor %}'); background-size:cover;background-position: center center;\">
               <div class=\"text-lg md:text-2xl text-secondary flex justify-between items-center\">{{p.title}}
                  {% for photo in p.header.image %}
                     {{ dump(p) }}

                     {{ dump(p.url) }}
                     <div class=\"w-1/5\" style=\"width: 50px\">
                        {{ page.find(p.url).media[photo.name].html(item.title, item.title, 'w-full') }}
                     </div>

                  {% endfor %}
               </div>
            </div>
         </a>
      {% endfor %}
   </div>
   <div class=\"text-center\">
      <a class=\"text-2xl text-white cutive\" href=\" {{ page.parent.url }} \">Zpět</a>
   </div>
{% endblock %}
", "stezka-list.html.twig", "B:\\Cloud\\GDrive\\_WebDesign\\laragon\\jinci\\user\\themes\\jinci-cin\\templates\\stezka-list.html.twig");
    }
}
