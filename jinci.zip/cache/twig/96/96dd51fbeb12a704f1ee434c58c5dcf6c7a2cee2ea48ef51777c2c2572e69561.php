<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* about.html.twig */
class __TwigTemplate_76dcd676f0c871fe10dd679631dc63cfbad33a5bed932e6e5ada807f7829e575 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("partials/base.html.twig", "about.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "   <div class=\"container mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h1 class=\"text-center mb-8 md:mb-16\">O Jinčím</h1>

         <div class=\"bylo__items lg:w-4/5 mx-auto transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               ";
        // line 10
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->markdownFunction($this->getAttribute(($context["page"] ?? null), "content", []));
        echo "
            </div>
         </div>
      </section>

      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h2 class=\"text-center mb-8 text-5xl\">Kdo za Jinčím stojí?</h2>

      </section>

      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h2 class=\"text-center mb-8 text-5xl\">A kdo ještě?</h2>

         <div class=\"bylo__items lg:w-4/5 mx-auto transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               ";
        // line 25
        echo $this->env->getExtension('Grav\Common\Twig\TwigExtension')->markdownFunction($this->getAttribute(($context["header"] ?? null), "text", []));
        echo "
            </div>
         </div>
      </section>
   </div>
";
    }

    public function getTemplateName()
    {
        return "about.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 25,  50 => 10,  42 => 4,  39 => 3,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/base.html.twig' %}

{% block content %}
   <div class=\"container mx-auto\">
      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h1 class=\"text-center mb-8 md:mb-16\">O Jinčím</h1>

         <div class=\"bylo__items lg:w-4/5 mx-auto transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               {{page.content|markdown}}
            </div>
         </div>
      </section>

      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h2 class=\"text-center mb-8 text-5xl\">Kdo za Jinčím stojí?</h2>

      </section>

      <section class=\"pt-8 md:pt-8 px-4 block program\">
         <h2 class=\"text-center mb-8 text-5xl\">A kdo ještě?</h2>

         <div class=\"bylo__items lg:w-4/5 mx-auto transition2-fade\">
            <div class=\"bylo__text text-secondary md:w-full\" id=\"swup2\">
               {{header.text|markdown}}
            </div>
         </div>
      </section>
   </div>
{% endblock %}
", "about.html.twig", "B:\\Cloud\\GDrive\\_WebDesign\\laragon\\jinci\\user\\themes\\jinci-cin\\templates\\about.html.twig");
    }
}
