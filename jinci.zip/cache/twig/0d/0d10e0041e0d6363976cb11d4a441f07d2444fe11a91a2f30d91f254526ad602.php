<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/header.html.twig */
class __TwigTemplate_243beed326452fecd754fac1c712ee0a41b205c0ea0eb40efb4d7e8e5175b05f extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
            'header_navigation' => [$this, 'block_header_navigation'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"header\">
   <div class=\"container mx-auto flex flex-col md:flex-row justify-between items-center\">
      <a class=\"logo left\" href=\"";
        // line 3
        echo (((($context["base_url"] ?? null) == "")) ? ("/") : (($context["base_url"] ?? null)));
        echo "\">
         ";
        // line 4
        echo $this->getAttribute($this->getAttribute(($context["config"] ?? null), "site", []), "title", []);
        echo "
      </a>
      <div class=\"hamburger__wrapper cutive\" id=\"js-hamburger-wrapper\">
         <button class=\"hamburger hamburger--squeeze\" id=\"js-hamburger\">
            <div class=\"hamburger-box\">
               <div class=\"hamburger-inner\"></div>
            </div>
         </button>
         MENU
      </div>

      ";
        // line 15
        $this->displayBlock('header_navigation', $context, $blocks);
        // line 20
        echo "
      <script>
         var el = document.getElementById('nav');
         var button = document.getElementById(\"js-hamburger\");
         var wrapper = document.getElementById(\"js-hamburger-wrapper\");

         function myFunction() {
            el.classList.toggle(\"active\");
            button.classList.toggle(\"is-active\");
         }
         el.onclick = myFunction;
         wrapper.onclick = myFunction;
      </script>
   </div>
</div>
";
    }

    // line 15
    public function block_header_navigation($context, array $blocks = [])
    {
        // line 16
        echo "         <nav class=\"main-nav cutive\" id=\"nav\">
            ";
        // line 17
        $this->loadTemplate("partials/navigation.html.twig", "partials/header.html.twig", 17)->display($context);
        // line 18
        echo "         </nav>
      ";
    }

    public function getTemplateName()
    {
        return "partials/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 18,  80 => 17,  77 => 16,  74 => 15,  55 => 20,  53 => 15,  39 => 4,  35 => 3,  31 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"header\">
   <div class=\"container mx-auto flex flex-col md:flex-row justify-between items-center\">
      <a class=\"logo left\" href=\"{{ base_url == '' ? '/' : base_url }}\">
         {{ config.site.title }}
      </a>
      <div class=\"hamburger__wrapper cutive\" id=\"js-hamburger-wrapper\">
         <button class=\"hamburger hamburger--squeeze\" id=\"js-hamburger\">
            <div class=\"hamburger-box\">
               <div class=\"hamburger-inner\"></div>
            </div>
         </button>
         MENU
      </div>

      {% block header_navigation %}
         <nav class=\"main-nav cutive\" id=\"nav\">
            {% include 'partials/navigation.html.twig' %}
         </nav>
      {% endblock %}

      <script>
         var el = document.getElementById('nav');
         var button = document.getElementById(\"js-hamburger\");
         var wrapper = document.getElementById(\"js-hamburger-wrapper\");

         function myFunction() {
            el.classList.toggle(\"active\");
            button.classList.toggle(\"is-active\");
         }
         el.onclick = myFunction;
         wrapper.onclick = myFunction;
      </script>
   </div>
</div>
", "partials/header.html.twig", "B:\\Cloud\\GDrive\\_WebDesign\\laragon\\jinci\\user\\themes\\jinci-cin\\templates\\partials\\header.html.twig");
    }
}
