<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* default.html.twig */
class __TwigTemplate_63240aa722fb0a16745cc2f9d3ea5de1d02f0d4479acf1125afc229acc9ec892 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent = $this->loadTemplate("partials/base.html.twig", "default.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        // line 4
        echo "   <div class=\"container mx-auto\">
      <section class=\"pt-8 md:pt-24 text-center block\">
         <h1>Jinčí čin</h1>
         <div class=\"flex justify-center flex-col md:flex-row items-center md:items-start transition2-fade\">
            <div class=\"max-w-sm m-4 md:mt-4 md:w-1/2 text-secondary leading-normal inline-block  text-left md:px-4\">
               <p>
                  Udělat to jinak, řekli jsme si na začátku a tak se zrodil Jinčí čin. Festival, který  se v roce 2016 stal oficiálním vedlejším  a nepohádkovým programem festivalu Jičín - město pohádky. Hlavním smyslem akce se stala oslava města Jičína - jeho ducha, míst, která jsou tak trochu opuštěná nebo málo využívána. Jinčí čin se proto za čtyři roky své existence odehrával na mnoha neobvyklých místech a ukázal, že i taková mohou ožít kulturním děním.
               </p>
            </div>
            <div class=\"max-w-sm mx-4 md:mt-4 md:w-1/2 text-secondary leading-normal inline-block  text-left md:px-4 md:mb-24\">
               <p>
                  Dramaturgie festivalu je postavená tak, aby nabídla něco dětem, rodičům či prarodičům (a samozřejmě také všem mezi). Program propojuje akademický přístup - přednášky a diskuze zaměřené s uměním - divadlem, tancem, kreativní tvorbou a hudbou. Každý rok se snažíme vybrat neotřelé české muzikanty.
               </p>
               <p class=\"text-white font-bold\">Festival se odehrává vždy druhý týden v září.
               </p>
            </div>
         </div>

         ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["item"] ?? null), "photo", []));
        foreach ($context['_seq'] as $context["_key"] => $context["photo"]) {
            // line 23
            echo "            ";
            // line 24
            echo "         ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['photo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "
         <div class=\"gallery md:mb-32\">
            ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["header"] ?? null), "radky", []));
        foreach ($context['_seq'] as $context["_key"] => $context["radek"]) {
            // line 28
            echo "               <div class=\"gallery__group\">
                  ";
            // line 29
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["radek"], "gallery", []));
            foreach ($context['_seq'] as $context["_key"] => $context["photo"]) {
                // line 30
                echo "                     <div class=\"gallery__item\">
                        ";
                // line 31
                echo $this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute($this->getAttribute(($context["page"] ?? null), "media", []), $this->getAttribute($context["photo"], "name", []), [], "array"), "lightbox", [0 => 1024, 1 => 768], "method"), "cropResize", [0 => 600, 1 => 600], "method"), "html", [0 => $this->getAttribute(($context["item"] ?? null), "title", []), 1 => $this->getAttribute(($context["item"] ?? null), "title", []), 2 => "w-full"], "method");
                echo "
                     </div>

                  ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['photo'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 35
            echo "               </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['radek'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "         </div>
      </section>

      ";
        // line 42
        echo "   </div>
";
    }

    public function getTemplateName()
    {
        return "default.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 42,  109 => 37,  102 => 35,  92 => 31,  89 => 30,  85 => 29,  82 => 28,  78 => 27,  74 => 25,  68 => 24,  66 => 23,  62 => 22,  42 => 4,  39 => 3,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/base.html.twig' %}

{% block content %}
   <div class=\"container mx-auto\">
      <section class=\"pt-8 md:pt-24 text-center block\">
         <h1>Jinčí čin</h1>
         <div class=\"flex justify-center flex-col md:flex-row items-center md:items-start transition2-fade\">
            <div class=\"max-w-sm m-4 md:mt-4 md:w-1/2 text-secondary leading-normal inline-block  text-left md:px-4\">
               <p>
                  Udělat to jinak, řekli jsme si na začátku a tak se zrodil Jinčí čin. Festival, který  se v roce 2016 stal oficiálním vedlejším  a nepohádkovým programem festivalu Jičín - město pohádky. Hlavním smyslem akce se stala oslava města Jičína - jeho ducha, míst, která jsou tak trochu opuštěná nebo málo využívána. Jinčí čin se proto za čtyři roky své existence odehrával na mnoha neobvyklých místech a ukázal, že i taková mohou ožít kulturním děním.
               </p>
            </div>
            <div class=\"max-w-sm mx-4 md:mt-4 md:w-1/2 text-secondary leading-normal inline-block  text-left md:px-4 md:mb-24\">
               <p>
                  Dramaturgie festivalu je postavená tak, aby nabídla něco dětem, rodičům či prarodičům (a samozřejmě také všem mezi). Program propojuje akademický přístup - přednášky a diskuze zaměřené s uměním - divadlem, tancem, kreativní tvorbou a hudbou. Každý rok se snažíme vybrat neotřelé české muzikanty.
               </p>
               <p class=\"text-white font-bold\">Festival se odehrává vždy druhý týden v září.
               </p>
            </div>
         </div>

         {% for photo in item.photo %}
            {#    #}
         {% endfor %}

         <div class=\"gallery md:mb-32\">
            {% for radek in header.radky %}
               <div class=\"gallery__group\">
                  {% for photo in radek.gallery %}
                     <div class=\"gallery__item\">
                        {{ page.media[photo.name].lightbox(1024,768).cropResize(600, 600).html(item.title, item.title, 'w-full') }}
                     </div>

                  {% endfor %}
               </div>
            {% endfor %}
         </div>
      </section>

      {#{{ page.content }}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      #}
   </div>
{% endblock %}
", "default.html.twig", "B:\\Cloud\\GDrive\\_WebDesign\\laragon\\jinci\\user\\themes\\jinci-cin\\templates\\default.html.twig");
    }
}
